static GtkSettings *toGtkSettings(void *p) { return (GTK_SETTINGS(p)); }
