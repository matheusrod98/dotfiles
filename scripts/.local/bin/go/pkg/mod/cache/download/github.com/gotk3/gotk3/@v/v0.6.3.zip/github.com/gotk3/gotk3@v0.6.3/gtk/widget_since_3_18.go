// +build !gtk_3_6,!gtk_3_8,!gtk_3_10,!gtk_3_12,!gtk_3_14,!gtk_3_16

package gtk

// #include <gtk/gtk.h>
import "C"

// TODO:
// gtk_widget_set_font_options().
// gtk_widget_get_font_options().
// gtk_widget_set_font_map().
// gtk_widget_get_font_map().
