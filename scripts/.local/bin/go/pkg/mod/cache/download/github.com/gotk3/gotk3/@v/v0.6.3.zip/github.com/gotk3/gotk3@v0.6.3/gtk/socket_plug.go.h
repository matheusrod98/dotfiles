
static GtkSocket *toGtkSocket(void *p) { return (GTK_SOCKET(p)); }

static GtkPlug *toGtkPlug(void *p) { return (GTK_PLUG(p)); }

static GdkDisplay *toGdkDisplay(void *p) { return (GDK_DISPLAY(p)); }
