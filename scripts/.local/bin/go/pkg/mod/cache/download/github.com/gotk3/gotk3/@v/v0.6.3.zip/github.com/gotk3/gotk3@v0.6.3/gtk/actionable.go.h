static GtkActionable *toGtkActionable(void *p) { return (GTK_ACTIONABLE(p)); }
