//+build gtk_3_6 gtk_3_8 gtk_3_10 gtk_3_12 gtk_3_14 gtk_3_16 gtk_deprecated

package gtk

/*
 * GtkPlacesSidebar
 */

// TODO:
// gtk_places_sidebar_get_show_connect_to_server().
// gtk_places_sidebar_set_show_connect_to_server().
